# Financial Overview Artifact

Create a professional interactive financial dashboard intended for a finance or management audience.

The first view should make it possible to understand the overall financial situation without inspecting individual transactions.


# Header

Show:

- Company
- Reporting period
- Currency
- Comparison basis
- Data retrieval time


# Executive KPIs

Display the most relevant available KPIs as visual cards.

Prioritize:

- Revenue YTD
- Gross profit YTD
- Gross margin percentage
- Operating result
- Cash and bank
- Accounts receivable
- Overdue accounts receivable
- Accounts payable

Use consistent number formatting.

Make negative values and material variances visually identifiable without relying exclusively on color.


# Profit and loss

Create a clear P&L section.

Where data is available, show:

- Revenue
- Cost of goods sold
- Gross profit
- Operating expenses
- Operating result

Compare actual versus budget.

Make variance and variance percentage easy to understand.

Allow the user to access supporting detail without showing all general ledger accounts in the main view.


# Balance sheet

Create a visual balance sheet section.

Group information into:

- Assets
- Liabilities
- Equity

Use relevant subtotals and a visualization that makes the relative composition understandable.


# Accounts receivable aging

Create a visualization of accounts receivable aging.

Use:

- Not due
- 1-30 days overdue
- 31-60 days overdue
- 61-90 days overdue
- More than 90 days overdue

Show the customers contributing the largest overdue balances.


# Accounts payable aging

Create a corresponding accounts payable aging visualization.

Make major vendor concentrations visible when relevant.


# Budget performance

Show material actual-versus-budget differences.

Prefer visuals that make magnitude and direction easy to understand.


# Interaction

Where appropriate, allow the user to:

- inspect additional detail
- expand supporting tables
- move from a summary to underlying categories
- understand which figures contribute to a total

Do not make the interface unnecessarily complex.


# Visual design

Use a professional enterprise dashboard design.

Prioritize:

- clear visual hierarchy
- readability
- accessible colors
- consistent spacing
- consistent number formatting
- concise labels
- responsive layout

Avoid decorative elements that do not help communicate the financial information.


# Data transparency

Clearly show:

- reporting scope
- assumptions
- unavailable data
- calculated metrics

Never hide unavailable data by displaying zero.

Do not include recommendations for business actions.