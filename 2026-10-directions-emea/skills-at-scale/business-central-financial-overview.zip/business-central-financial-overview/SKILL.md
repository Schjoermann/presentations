---
name: business-central-financial-overview
description: Builds a financial overview from Business Central, including profit and loss year to date, balance sheet, accounts receivable and accounts payable aging, budget comparison, and key financial indicators. Use this skill when the user asks how the business is doing or asks for a financial overview, financial performance, profit and loss, P&L, balance sheet, budget performance, budget variance, financial KPIs, gross margin, accounts receivable aging, accounts payable aging, or an overview of overdue receivables. Present the result as an interactive HTML artifact. This skill is read-only. Never create, update, delete, or post Business Central data.
---

# Purpose

Create a clear, factual, and visually engaging financial overview from Business Central.

Turn financial Business Central data into an executive-friendly interactive HTML artifact rather than returning raw records or large tables in the conversation.

# Business Central access

Access Business Central exclusively through the configured Origo MCP server.

Use Origo MCP to retrieve all Business Central data required for the analysis.

Do not use another connector, API, flow, knowledge source, or external source for Business Central data.

This skill is strictly read-only.

Never:

- create records
- update records
- delete records
- post documents or journals
- change Business Central configuration

# Determine the reporting scope

Before building the overview, determine:

1. The Business Central company.
2. The reporting end date.
3. The current financial year.
4. The base currency.
5. The available budget and comparison period.

When the user asks a general question such as "How is the business doing?" and does not provide a period, use year to date through the latest completed month when the required data is available.

Clearly show the company, period, currency, and comparison basis in the final artifact.

# Financial overview

Include the following sections when the required data is available.

## Executive KPIs

Calculate and present relevant headline metrics such as:

- Revenue year to date
- Gross profit year to date
- Gross margin percentage
- Operating result
- Cash and bank balance
- Accounts receivable
- Overdue accounts receivable
- Accounts payable

Do not invent values when the required data is unavailable.

Clearly indicate when a metric cannot be calculated.


## Profit and loss

Present profit and loss year to date.

Where meaningful and available, show:

- Actual year to date
- Budget year to date
- Variance
- Variance percentage

Group financial accounts into understandable business categories rather than exposing a raw list of general ledger accounts.

Preserve the underlying Business Central values.


## Balance sheet

Present the current balance sheet.

Where possible, organize the result into:

- Assets
- Liabilities
- Equity

Present relevant subtotals.


## Accounts receivable aging

Analyze open customer entries and present accounts receivable aging.

Use aging buckets:

- Not due
- 1-30 days overdue
- 31-60 days overdue
- 61-90 days overdue
- More than 90 days overdue

Highlight customers with material overdue balances.


## Accounts payable aging

Analyze open vendor entries and present accounts payable aging using the same aging approach.


## Budget comparison

When Business Central budget data is available, compare actual financial performance against budget.

Show:

- Actual
- Budget
- Variance
- Variance percentage

Highlight material differences visually.

Do not interpret a variance as good or bad unless the accounting context supports that conclusion.

# Analysis boundaries

This skill presents and explains the financial situation.

It may identify factual observations and material differences in the data.

It must not recommend what the business should do.

Examples:

Allowed:

"Gross margin is 3.2 percentage points below budget."

Not allowed:

"We should increase prices to improve gross margin."

Allowed:

"Customer A represents the largest overdue receivable."

Not allowed:

"Finance should immediately contact Customer A."

The purpose of this skill is to help the user understand what is happening, not decide how the business should respond.

# Interactive artifact

Present the finished financial overview as an interactive HTML artifact.

Follow the presentation and layout requirements defined in:

references/financial-overview-artifact.md

Prioritize visual understanding rather than presenting a large text report.

# Data integrity

Never fabricate missing financial values.

Never silently replace missing data with zero.

If information cannot be retrieved or calculated, clearly indicate that it is unavailable.

Keep calculated metrics separate from values directly retrieved from Business Central.

When a calculation is performed, use the Business Central values exactly as retrieved.

Do not change the meaning, sign, scale, or unit of a Business Central value unless explicitly required for the calculation.

# Completion criteria

The task is complete when:

1. The relevant Business Central financial data has been retrieved through Origo MCP.
2. The requested metrics have been calculated where possible.
3. The financial overview has been created as an interactive HTML artifact.
4. The company, period, currency, and comparison basis are visible.
5. Important figures are supported by the retrieved Business Central data.
6. Missing data and assumptions are clearly identified.
7. No Business Central records have been modified.