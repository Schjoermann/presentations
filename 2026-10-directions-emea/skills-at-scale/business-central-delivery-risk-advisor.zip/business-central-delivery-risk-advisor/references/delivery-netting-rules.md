# Delivery Availability and Netting Rules

Use these rules when determining whether an open sales order can be fulfilled by its required shipment date.


# Net at the correct level

Evaluate availability using the relevant:

- item
- variant, when applicable
- unit of measure
- location
- required shipment date

Do not use total company inventory as a substitute for location-specific availability.


# On-hand inventory

Start with inventory available at the relevant location.

Account for inventory that is already committed or reserved when that information is available.

Do not assume reserved or otherwise committed inventory is available for another order.


# Demand priority

Account for other demand that consumes the same inventory before the analyzed sales line.

Use chronological requirement dates when no other explicit Business Central priority is available.

Do not allocate the same available quantity to multiple sales orders.


# Incoming supply

Consider relevant incoming supply when supported by Business Central data.

This may include:

- purchase orders
- transfer orders
- production orders
- assembly orders

Only count supply when its expected availability at the required location is on or before the sales line's required shipment date.


# Late supply

Supply arriving after the required shipment date does not make the order fulfillable on time.

Show late supply separately when it is useful for explaining when the order could become fulfillable.


# Alternative locations

Inventory at another location is not automatically available for the sales order.

Treat it as a potential corrective option.

Before recommending a transfer, evaluate whether:

- sufficient uncommitted inventory exists at the alternative location
- moving the quantity would create risk for other demand
- the transfer can realistically make the inventory available before the required shipment date, when the necessary timing data is available


# Avoid double counting

Never count the same:

- inventory
- purchase supply
- transfer supply
- production supply
- assembly supply

more than once.


# Missing data

When required information is unavailable, state the limitation.

Do not replace unavailable quantities or dates with assumed values.

Classify the result as insufficient data when a reliable delivery conclusion cannot be made.


# Explain the calculation

For every identified delivery risk, make it possible to understand:

- remaining demand
- inventory considered
- earlier demand considered
- incoming supply considered
- supply excluded because it arrives too late
- calculated available quantity
- calculated shortage