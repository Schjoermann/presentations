---
name: business-central-delivery-risk-advisor
description: Identifies customers and open sales orders at risk of late or short delivery in Business Central and recommends corrective actions. Use this skill when the user asks about late deliveries, delivery risk, shortages, orders that will ship late, orders that cannot be fulfilled, past-due orders, whether an order can be fulfilled, or whether orders can be delivered on time. Analyze open demand against location-specific inventory and incoming supply available before each required shipment date. Explain each recommendation and its expected impact. Analysis is read-only and never modifies Business Central data.
---

# Purpose

Identify customers and open sales orders that are at risk of late or short delivery and recommend the most appropriate corrective action.

The skill must determine whether each sales order can be fulfilled by its required shipment date using the inventory and supply that will actually be available at the relevant location at that time.

The output must explain:

- what is at risk
- why it is at risk
- how large the shortage is
- what options exist
- which action is recommended
- why that action is preferred
- what impact the action could have elsewhere

This skill provides decision support.

It does not modify Business Central data.

# Business Central access

Access Business Central exclusively through the configured Origo MCP server.

Use current Business Central data for every analysis.

Do not use another connector, API, flow, knowledge source, or external source for Business Central data.

This skill is read-only.

Never:

- create records
- update records
- delete records
- reserve inventory
- release documents
- post documents
- change shipment dates
- create supply orders
- create transfer orders
- modify Business Central configuration

# Determine the analysis scope

Unless the user specifies another period, analyze:

- open sales orders with a required shipment date within the next 14 days
- past-due open sales orders that have not been completely fulfilled

Determine the current date at runtime.

For each relevant sales order, identify the required information needed to evaluate whether the remaining quantity can be fulfilled on time.

Keep the analysis at the level required to distinguish:

- customer
- sales order
- sales line
- item
- variant, when relevant
- unit of measure
- location
- required shipment date
- remaining quantity

# Delivery availability calculation

Follow the delivery availability and netting rules defined in:

references/delivery-netting-rules.md

Do not determine delivery feasibility from total company inventory alone.

Availability must be evaluated for the relevant item, location, and required date.

Do not treat future supply as available when it arrives after the order requires it.

Do not count the same inventory or incoming supply more than once.

# Identify delivery risk

Classify each relevant sales order or sales line based on the available Business Central data.

Use categories such as:

## On track

The remaining quantity can be fulfilled at the required location by the required shipment date.

## At risk

Available inventory and qualifying incoming supply might not be sufficient or reliable enough to meet the required shipment date.

## Short

The available quantity by the required shipment date is lower than the remaining quantity.

## Past due

The required shipment date has passed and the order still contains an outstanding quantity.

For orders that are not on track, identify the primary reason for the risk.

# Evaluate corrective options

For each order that is at risk, short, or past due, investigate applicable corrective options using current Business Central data.

Potential options may include:

- inventory available at another location
- an existing transfer that can arrive in time
- an existing purchase order that can arrive in time
- an existing production or assembly order that can arrive in time
- expediting existing supply
- transferring inventory between locations
- splitting the delivery
- using an appropriate alternative item when supported by available data
- moving the promised or requested delivery date

Do not recommend an option unless the Business Central data supports it.

Do not assume that inventory at another location can be transferred in time unless the available data supports that conclusion.

Do not assume that incoming supply can solve the shortage when its expected availability is later than the required shipment date.

# Recommendation method

For every affected order, recommend the most appropriate corrective action when sufficient data is available.

Prefer options that:

1. Protect the customer commitment.
2. Require the least operational disruption.
3. Avoid creating a new shortage for another customer or location.
4. Use existing inventory or supply when appropriate before proposing unnecessary new supply.
5. Are supported by current Business Central data.

When multiple viable options exist, present the alternatives and explain why one is preferred.

Clearly distinguish:

- Business Central facts
- calculated delivery risk
- assumptions
- recommendation

# Output contract

Start with a concise delivery-risk summary.

Include:

- number of affected customers
- number of affected sales orders
- overall pattern of the identified risks

Do not invent counts when the retrieved data is incomplete.


# Affected orders

For each affected order present:

- Customer
- Sales order
- Required shipment date
- Item
- Location
- Remaining quantity
- Quantity available by the required date
- Short quantity
- Primary cause
- Relevant incoming supply
- Recommended action
- Rationale
- Expected impact
- Important trade-offs
- Business Central documents or records affected by the recommendation


# Recommended actions

Finish with a numbered list of concrete proposed actions.

For example:

1. Transfer the required quantity from an alternative location.
2. Expedite a specific existing supply document.
3. Split a specific sales order.
4. Change a specific promised delivery date.

Only include actions that are supported by the analyzed data.

# Action boundary

This skill may recommend and describe a Business Central change.

It may also explain exactly which records would be affected.

It must not execute the change.

A recommendation is not approval.

Do not interpret phrases such as:

- "sounds good"
- "that makes sense"
- "thanks"
- "handle it"

as authorization to modify Business Central.

If the user explicitly asks to perform a recommended action, make clear that execution requires an appropriate action capability with authority to modify the specified Business Central records.

Never claim that a recommended change has been made.

# Missing or uncertain data

Never guess when required information is unavailable.

If delivery feasibility cannot be determined because data is missing, identify the missing information.

Examples may include:

- missing location
- missing shipment date
- uncertain incoming supply date
- unresolved reservation information
- missing item availability
- incomplete supply information

Clearly distinguish:

- confirmed risk
- possible risk
- insufficient data

Do not present insufficient data as a confirmed shortage.

# Completion criteria

The task is complete when:

1. Relevant open and past-due sales orders have been identified.
2. Remaining demand has been evaluated against location-specific availability.
3. Only supply available by each required shipment date has been considered.
4. Delivery risk has been classified.
5. The reason for each identified risk has been explained.
6. Applicable corrective options have been evaluated.
7. Recommendations are supported by Business Central data.
8. Trade-offs and affected records are clearly identified.
9. Proposed actions are listed separately from completed actions.
10. No Business Central data has been modified.