# Delivery Action Guardrails

These guardrails apply whenever a delivery-related corrective action modifies Business Central.


# 1. Current state wins

Always use current Business Central data immediately before execution.

A previous recommendation can become outdated.

Never execute a recommendation solely because it was valid earlier in the conversation.


# 2. Minimum necessary change

Make the smallest Business Central change required to perform the approved action.

Do not create additional documents, lines, reservations, supply, or updates unless explicitly approved.


# 3. Exact record scope

Every write must be associated with identifiable Business Central records and an approved business purpose.

Do not perform broad or bulk corrections from a vague instruction.


# 4. Transfer validation

Before preparing a transfer, verify:

- the source location exists
- the destination location exists
- the locations are different
- the item exists
- the quantity is positive
- the relevant unit of measure is valid
- sufficient transferable inventory is supported by current data
- the transfer still addresses an identifiable delivery requirement
- the source inventory isn't already required by earlier demand when that data is available


# 5. Duplicate prevention

Before preparing a corrective document, inspect whether an existing open document already addresses the same requirement.

Do not knowingly create a duplicate transfer for the same requirement.


# 6. Approval

Approval must apply to the exact proposal currently presented.

If any material value changes after approval, including:

- item
- quantity
- source location
- destination location
- related requirement

stop and present the revised proposal for approval.


# 7. No downstream processing

Creating or preparing a document doesn't authorize processing it.

Never:

- release
- post
- ship
- receive

a document as part of this skill.


# 8. Verification

A tool call returning without an error isn't sufficient evidence of success.

Read the Business Central record back and validate its important values.


# 9. Partial failure

If an operation partially succeeds:

- stop
- identify what was created or changed
- don't automatically compensate
- don't create replacement records
- explain the current Business Central state


# 10. Final response

Clearly distinguish:

- requested action
- approved action
- executed action
- verified result
- actions deliberately not performed