---
name: business-central-delivery-action
description: Executes a specific and explicitly approved corrective action for a Business Central delivery risk. Use this skill when the user explicitly asks to perform, prepare, create, or apply a previously recommended or clearly specified delivery correction, such as preparing a transfer between locations. Always revalidate the current Business Central state before execution, show the exact proposed change, require specific approval, execute only the approved change, and verify the resulting Business Central record. Never post, ship, receive, release, delete, or execute unrelated changes.
---

# Purpose

Execute a specific corrective action for a Business Central delivery risk after the action has been clearly identified and explicitly approved.

This skill represents the transition from recommendation to controlled execution.

A recommendation is not an instruction to execute it.

The skill must:

1. Understand the requested action.
2. Revalidate the current Business Central state.
3. Determine whether the proposed action is still appropriate.
4. Present the exact proposed Business Central change.
5. Obtain explicit approval.
6. Execute only the approved change.
7. Read the resulting Business Central record back.
8. Verify the result.
9. Stop before any posting, shipment, receipt, release, or further processing.


# Business Central access

Access Business Central exclusively through the configured Origo MCP server.

Use current Business Central data when validating and executing the action.

Do not use another connector, API, flow, knowledge source, or external source for Business Central data or actions.

Use only Business Central capabilities exposed through the configured Origo MCP server.


# Supported action scope

Initially support controlled preparation of delivery-related corrective actions that can remain unposted.

The primary supported action for this demonstration is:

- prepare a transfer order between Business Central locations

Other action types may only be used when they are explicitly supported by this skill, the available Business Central capabilities, and the user's request.

Do not expand the requested action into additional changes.


# Action source

The requested action may originate from:

- a recommendation produced earlier in the conversation
- a numbered recommendation from the Delivery Risk Advisor skill
- an explicitly specified corrective action supplied by the user

When the action originates from an earlier recommendation, do not assume that the earlier analysis is still current.

Revalidate it.


# Revalidation

Before preparing any Business Central change, retrieve the current data required to validate the proposed action.

For a proposed transfer, verify:

- source location
- destination location
- item
- variant when relevant
- unit of measure
- proposed quantity
- current source availability
- current demand at the source location
- current shortage at the destination location
- sales order or orders the transfer is intended to protect
- required shipment date
- relevant incoming supply
- existing transfer documents that may already address the shortage

Do not execute the action when the current state no longer supports the recommendation.


# Revalidation result

Classify the proposed action as:

## Still valid

The current Business Central data continues to support the proposed action.

## Needs adjustment

The business problem still exists, but current data indicates that the proposed quantity, source, destination, date, or other value should change.

Do not silently adjust the action.

Present the changed proposal and require new approval.

## No longer required

The underlying problem has been resolved or sufficient availability now exists.

Do not execute the action.

## Cannot validate

Required Business Central information is missing or uncertain.

Do not execute the action.


# Existing corrective actions

Before creating a new record, check whether an existing open Business Central document already addresses the same requirement.

For a transfer, check for relevant existing transfer documents when that information is available.

Do not knowingly create duplicate corrective documents.


# Proposed change

When the action remains valid, present the exact proposed change before execution.

For a transfer order, clearly show:

- Source location
- Destination location
- Item
- Variant when relevant
- Unit of measure
- Quantity
- Related sales order or business requirement
- Required date when relevant
- Expected effect

Clearly state:

"No document will be posted, shipped, received, or released by this action."


# Explicit approval

Do not modify Business Central without explicit approval of the specific proposed change.

Approval must be specific enough to identify the action being approved.

Examples of sufficient approval:

- "Create that transfer order."
- "Proceed with recommendation 1 as shown."
- "Confirmed. Create the proposed transfer."

General conversational responses such as:

- "sounds good"
- "interesting"
- "thanks"
- "that makes sense"

are not approval.

If the proposal has changed since the user's earlier instruction, require approval of the updated proposal.


# Execution

After explicit approval:

1. Use the configured Origo MCP server to prepare only the approved Business Central record.
2. Use the exact approved values.
3. Do not add unrelated lines or changes.
4. Keep the resulting document unposted and unprocessed.
5. Capture the Business Central identifiers returned by the operation.

Follow the action guardrails in:

references/delivery-action-guardrails.md


# Verification

After the Business Central write:

1. Read the created or modified record back through Origo MCP.
2. Verify the document exists.
3. Verify source and destination locations.
4. Verify item and variant when relevant.
5. Verify unit of measure.
6. Verify quantity.
7. Verify the document remains unposted.
8. Verify no additional unapproved lines were introduced.

Never report success solely because the write request was submitted.


# Result

Report one of:

## Prepared successfully

Include:

- Business Central document type
- Document number or identifier
- Source
- Destination
- Item
- Quantity
- Related order or requirement
- Verification status

Clearly state that the document has not been posted, shipped, received, or released.


## Not executed

Explain why:

- recommendation is no longer valid
- current state requires a revised proposal
- required information is unavailable
- explicit approval hasn't been provided
- the operation failed


## Failed

Explain the failure returned by Business Central or Origo MCP.

Do not hide or reinterpret the error.


# Hard boundaries

Never:

- post a transfer order
- ship a transfer order
- receive a transfer order
- release a document
- post a sales order
- post a purchase order
- delete a Business Central record
- execute an unapproved change
- create additional supply that wasn't approved
- change an unrelated sales order
- change promised or requested dates unless that specific action is supported and explicitly approved
- retry a failed operation with different business values without explaining the change and obtaining approval


# Completion criteria

The action is complete when:

1. The requested corrective action has been identified.
2. Current Business Central data has been retrieved.
3. The recommendation has been revalidated.
4. The exact proposed change has been presented.
5. Specific approval has been obtained.
6. Only the approved Business Central change has been made.
7. The resulting record has been read back and verified.
8. No additional action has been performed.
9. Nothing has been posted, shipped, received, or released.